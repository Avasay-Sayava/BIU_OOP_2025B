package collision;

import geometry.Circle;
import geometry.Line;
import geometry.Shape;
import util.Constants;
import util.ValueSet;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * This class represents a collider for a ball.
 */
public class CircleCollider extends Collider<Circle> {
    private int count;
    private final Set<Line> lines;

    /**
     * Constructor.
     *
     * @param shape the ball to collide
     */
    public CircleCollider(Circle shape) {
        super(shape);
        this.count = 0;
        this.lines = new ValueSet<>();
    }

    /**
     * Collides with a shape.
     *
     * @param object the object to collide with
     */
    @Override
    public void collide(Shape object) {
        for (Line line : object.getPolygon(Constants.POLYGON_ACCURACY_FACTOR).getLines()) {
            if (this.getShape().isIntersecting(line)) {
                collide(line);
            }
        }
    }

    /**
     * Collides with a collidable.
     *
     * @param object the object to collide with
     */
    @Override
    public void defaultCollide(Collidable object) {
        this.count++;
        change(object.hit(this.getShape().getLastCenter(), this.getShape().getVelocity())
                .subtract(this.getShape().getVelocity()));
    }

    @Override
    public void collide(Line line) {
        this.count++;
        this.lines.add(line);
    }

    /**
     * Applies the collision to the ball.
     */
    @Override
    public void apply() {
        List<Line> list = new ArrayList<>(this.lines.stream()
                .filter(l -> this.getShape().intersectionType(l)
                        != Circle.IntersectionType.ON_VERTEX).toList());
        if (list.isEmpty()) {
            this.lines.forEach(this::defaultCollide);
        } else {
            list.stream().max(Comparator.comparingDouble(l -> l.distance(getShape())))
                    .ifPresent(this::defaultCollide);
        }
        this.lines.clear();
        if (this.count == 0) {
            this.getShape().updateLastCenter();
        } else {
            this.count = 0;
        }
        super.apply();
    }
}
