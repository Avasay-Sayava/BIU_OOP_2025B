package graphics;

import biuoop.DrawSurface;
import geometry.Point;
import geometry.Rectangle;

import java.awt.Color;

/**
 * A block is a rectangle with a color.
 */
public class Block extends Rectangle implements Sprite, Colored {
    private Color color;

    /**
     * Copy constructor.
     *
     * @param other the block to copy
     */
    public Block(Block other) {
        this(other, other.getColor());
    }

    /**
     * Copy constructor.
     *
     * @param other the rectangle to copy
     * @param color the color of the block
     */
    public Block(Rectangle other, Color color) {
        this(other.topLeft(), other.getWidth(), other.getHeight(), color);
    }

    /**
     * Constructor.
     *
     * @param topLeft the top left point of the rectangle
     * @param width   the width of the rectangle
     * @param height  the height of the rectangle
     * @param color   the color of the block
     */
    public Block(Point topLeft, double width, double height, Color color) {
        this(topLeft, new Point(topLeft).add(new Point(width, height)), color);
    }

    /**
     * Constructor.
     *
     * @param point1 the first point
     * @param point2 the second point
     * @param color  the color of the block
     */
    public Block(Point point1, Point point2, Color color) {
        this(point1.getX(), point1.getY(), point2.getX(), point2.getY(), color);
    }

    /**
     * Constructor.
     *
     * @param x1    the x coordinate of the first point
     * @param y1    the y coordinate of the first point
     * @param x2    the x coordinate of the second point
     * @param y2    the y coordinate of the second point
     * @param color the color of the block
     */
    public Block(double x1, double y1, double x2, double y2, Color color) {
        super(x1, y1, x2, y2);
        this.color = color;
    }

    /**
     * @return The color of the object
     */
    @Override
    public Color getColor() {
        return this.color;
    }

    /**
     * @param color The color to set
     */
    @Override
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * @param d the DrawSurface to draw on
     */
    @Override
    public void drawOn(DrawSurface d) {
        Point topLeft = topLeft();
        d.setColor(getColor());
        d.fillRectangle((int) Math.round(topLeft.getX()), (int) Math.round(topLeft.getY()),
                (int) Math.round(getWidth()), (int) Math.round(getHeight()));
        d.setColor(Color.BLACK);
        d.drawRectangle((int) Math.round(topLeft.getX()), (int) Math.round(topLeft.getY()),
                (int) Math.round(getWidth()), (int) Math.round(getHeight()));
    }

    /**
     * passes the time doing a useless thing.
     */
    @Override
    public void timePassed() {

    }
}
