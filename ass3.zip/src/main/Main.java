/*
Name: Aviv Sayer
ID: 326552304
 */

package main;

/**
 * The main class.
 */
public class Main {
    /**
     * The main method.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Game game = new Ass3Game();
        game.initialize();
        game.run();
    }
}
