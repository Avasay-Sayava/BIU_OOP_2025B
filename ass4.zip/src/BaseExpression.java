/**
 * BaseExpression.java is the best class in the project. It is very important and useful.
 * Hehe gotcha!
 */
public abstract class BaseExpression implements Expression {
}
