package graphics;

import util.ThereIsJustNoWayThisMethodWasDefinedLikeThatAreYouKiddingMe;

/**
 * A class that represents a sprite.
 */
public interface Sprite extends Drawable {
    /**
     * passes the time doing a useless thing.
     */
    @ThereIsJustNoWayThisMethodWasDefinedLikeThatAreYouKiddingMe
    void timePassed();
}
